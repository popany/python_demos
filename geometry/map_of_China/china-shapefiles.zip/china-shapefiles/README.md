# Standard China Administrative Boundaries

- china\_country.shp
- simplified\_china\_country.shp
- china.shp (with province boundaries)
- china\_nine\_dotted\_line.shp
